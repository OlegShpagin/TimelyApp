# TimelyApp

Timely alarm

Timely alarm is a simple and easy to use alarm app that helps its user to set repeating or single alarms.

Features:
-switch between dark and white​ mode
-swipe delete alarm item functionality
-schedule multiple repeating alarms
-alarm off and alarm on functionality​
-user friendly interface
-suave design
And lots more

Installation
We assume you've installed android studio already, Unzip the file and open it in android studio, sync and run..
Note: you need a basic knowledge of java or kotlin to understand this app’s source code.

How To Use
-After installing successfully on android studio, run on a virtual device or a physical device.
 navigate to the home page, click on the FAB(floating action button) “+” to create a new task.
-to change app logo, go to res -> drawable-> image asset -> path(below foreground layer)
And choose your specific logo,then navigate to the manifest.xml file, look for android:roundIcon under application and change it to yours.

Happy using

-to change the logo, About ME
My name is Abundance Nkereuwem, an undergraduate student of Computer Science in china
I love programing, i have been coding constantly for two years and I love it, stay tuned for more projects.
Feel free to message on Instagram @dremo.dev
